
export const getBigNum = (arr) => {
  return Math.max(...arr)
}